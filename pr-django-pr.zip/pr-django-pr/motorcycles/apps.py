from django.apps import AppConfig


class MotorcyclesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'motorcycles'
