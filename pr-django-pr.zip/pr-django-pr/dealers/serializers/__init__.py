from .motorcycle import DealerSerializer
from .dealer import MotorcycleDealerSerializer
